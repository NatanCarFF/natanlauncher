package com.natancarff.launcher

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.natancarff.launcher.ui.theme.LauncherTheme

const val PREFS_NAME = "LauncherPrefs"
const val PREF_BACKGROUND_COLOR_KEY = "backgroundColor"
const val PREF_BACKGROUND_IMAGE_URI_KEY = "backgroundImageUri"
const val PREF_TEXT_ICON_COLOR_KEY = "textIconColor"

class SettingsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LauncherTheme {
                val context = LocalContext.current
                var backgroundColor by remember { mutableIntStateOf(getDefaultBackgroundColor(context)) }
                var backgroundImageUri by remember { mutableStateOf<String?>(null) }
                var textIconColor by remember { mutableIntStateOf(getDefaultTextIconColor(context)) }

                val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

                LaunchedEffect(Unit) {
                    backgroundColor = prefs.getInt(PREF_BACKGROUND_COLOR_KEY, Color.White.toArgb())
                    backgroundImageUri = prefs.getString(PREF_BACKGROUND_IMAGE_URI_KEY, null)
                    textIconColor = prefs.getInt(PREF_TEXT_ICON_COLOR_KEY, Color.Black.toArgb())
                }

                DisposableEffect(Unit) {
                    val listener = SharedPreferences.OnSharedPreferenceChangeListener { sharedPreferences, key ->
                        when (key) {
                            PREF_BACKGROUND_COLOR_KEY -> {
                                backgroundColor = sharedPreferences.getInt(PREF_BACKGROUND_COLOR_KEY, Color.White.toArgb())
                            }
                            PREF_BACKGROUND_IMAGE_URI_KEY -> {
                                backgroundImageUri = sharedPreferences.getString(PREF_BACKGROUND_IMAGE_URI_KEY, null)
                            }
                            PREF_TEXT_ICON_COLOR_KEY -> {
                                textIconColor = sharedPreferences.getInt(PREF_TEXT_ICON_COLOR_KEY, Color.Black.toArgb())
                            }
                        }
                    }
                    prefs.registerOnSharedPreferenceChangeListener(listener)
                    onDispose {
                        prefs.unregisterOnSharedPreferenceChangeListener(listener)
                    }
                }

                Box(
                    modifier = Modifier.fillMaxSize()
                ) {
                    if (backgroundImageUri != null) {
                        AsyncImage(
                            model = backgroundImageUri,
                            contentDescription = "Background Image",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color(backgroundColor))
                        )
                    }

                    SettingsScreen(
                        onBackPressed = { finish() },
                        context = context,
                        textIconColor = Color(textIconColor)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onBackPressed: () -> Unit, context: Context, textIconColor: Color) {
    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            saveBackgroundImageUri(context, it.toString())
            // Não chame clearBackgroundColor aqui, pois saveBackgroundImageUri já define a imagem
        }
    }

    val backgroundColors = listOf(
        Color.White,
        Color.LightGray,
        Color.Cyan,
        Color.Yellow,
        Color.Magenta,
        Color.Green,
        Color.Blue,
        Color.Red,
        Color(0xFF800080), // Roxo
        Color(0xFFFFA500), // Laranja
        Color(0xFF4B0082), // Índigo
        Color(0xFFEE82EE)  // Violeta
    )

    val textIconColors = listOf(
        Color.Black,
        Color.White,
        Color.Gray,
        Color.Red,
        Color.Blue,
        Color.Green,
        Color(0xFF800080), // Roxo
        Color(0xFFFFA500)  // Laranja
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                title = { Text("Configurações", color = textIconColor) },
                navigationIcon = {
                    IconButton(onClick = onBackPressed) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Voltar", tint = textIconColor)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent
                )
            )
        }
    ) { innerPadding ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            contentPadding = PaddingValues(bottom = 16.dp)
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Text(
                    text = "Cor de Fundo Padrão",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = textIconColor,
                    modifier = Modifier.padding(top = 16.dp, bottom = 8.dp)
                )
            }
            items(backgroundColors) { color ->
                ColorOption(color = color) { selectedColor ->
                    saveBackgroundColor(context, selectedColor)
                }
            }

            item(span = { GridItemSpan(maxLineSpan) }) {
                Text(
                    text = "Plano de Fundo de Imagem",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = textIconColor,
                    modifier = Modifier.padding(top = 24.dp, bottom = 8.dp)
                )
            }
            item(span = { GridItemSpan(maxLineSpan) }) {
                ActionOption(text = "Selecionar Imagem da Galeria", textIconColor = textIconColor) {
                    imagePickerLauncher.launch("image/*")
                }
            }
            item(span = { GridItemSpan(maxLineSpan) }) {
                ActionOption(text = "Remover Imagem de Fundo", textIconColor = textIconColor) {
                    clearBackgroundImageUri(context)
                }
            }

            item(span = { GridItemSpan(maxLineSpan) }) {
                Text(
                    text = "Cor dos Ícones e Texto",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = textIconColor,
                    modifier = Modifier.padding(top = 24.dp, bottom = 8.dp)
                )
            }
            items(textIconColors) { color ->
                ColorOption(color = color) { selectedColor ->
                    saveTextIconColor(context, selectedColor)
                }
            }
        }
    }
}

// === Funções auxiliares para SharedPreferences (MODIFICADAS) ===

fun saveBackgroundImageUri(context: Context, uri: String) {
    val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    prefs.edit().apply {
        putString(PREF_BACKGROUND_IMAGE_URI_KEY, uri)
        remove(PREF_BACKGROUND_COLOR_KEY) // Garante que a cor sólida seja limpa se uma imagem for definida
    }.apply()
}

fun clearBackgroundImageUri(context: Context) {
    val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    prefs.edit().apply {
        remove(PREF_BACKGROUND_IMAGE_URI_KEY) // Remove a URI da imagem
        putInt(PREF_BACKGROUND_COLOR_KEY, Color.White.toArgb()) // Define o fundo para branco
        putInt(PREF_TEXT_ICON_COLOR_KEY, Color.Black.toArgb()) // Define o texto/ícone para preto
    }.apply()
}

fun saveBackgroundColor(context: Context, color: Color) {
    val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    prefs.edit().apply {
        putInt(PREF_BACKGROUND_COLOR_KEY, color.toArgb()) // Salva a cor sólida selecionada
        remove(PREF_BACKGROUND_IMAGE_URI_KEY) // Limpa qualquer URI de imagem de fundo existente
    }.apply()
}

fun clearBackgroundColor(context: Context) {
    val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    prefs.edit().remove(PREF_BACKGROUND_COLOR_KEY).apply()
}

fun saveTextIconColor(context: Context, color: Color) {
    val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    prefs.edit().putInt(PREF_TEXT_ICON_COLOR_KEY, color.toArgb()).apply()
}

fun getDefaultBackgroundColor(context: Context): Int {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    return prefs.getInt(PREF_BACKGROUND_COLOR_KEY, Color.White.toArgb())
}

fun getDefaultTextIconColor(context: Context): Int {
    val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    return prefs.getInt(PREF_TEXT_ICON_COLOR_KEY, Color.Black.toArgb())
}

// === Composables e funções auxiliares para UI (inalteradas neste passo) ===

fun getContrastingTextColor(backgroundColor: Color): Color {
    val luminance = backgroundColor.red * 0.299 + backgroundColor.green * 0.587 + backgroundColor.blue * 0.114
    return if (luminance > 0.5) Color.Black else Color.White
}

@Composable
fun ColorOption(color: Color, onColorSelected: (Color) -> Unit) {
    val colorName = remember { mutableStateOf(getColorName(color)) }
    val textColor = getContrastingTextColor(color)
    Text(
        text = colorName.value,
        modifier = Modifier
            .fillMaxWidth()
            .padding(4.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(color = color)
            .clickable { onColorSelected(color) }
            .padding(16.dp),
        color = textColor
    )
}

@Composable
fun ActionOption(text: String, textIconColor: Color, onClick: () -> Unit) {
    Text(
        text = text,
        modifier = Modifier
            .fillMaxWidth()
            .padding(4.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.primaryContainer)
            .clickable { onClick() }
            .padding(16.dp),
        color = textIconColor
    )
}

fun getColorName(color: Color): String {
    return when (color) {
        Color.White -> "Branco"
        Color.Black -> "Preto"
        Color.LightGray -> "Cinza Claro"
        Color.Cyan -> "Ciano"
        Color.Yellow -> "Amarelo"
        Color.Magenta -> "Magenta"
        Color.Gray -> "Cinza"
        Color.Red -> "Vermelho"
        Color.Blue -> "Azul"
        Color.Green -> "Verde"
        Color(0xFF800080) -> "Roxo"
        Color(0xFFFFA500) -> "Laranja"
        Color(0xFF4B0082) -> "Índigo"
        Color(0xFFEE82EE) -> "Violeta"
        else -> "Cor Personalizada"
    }
}

@Preview(showBackground = true)
@Composable
fun SettingsScreenPreview() {
    LauncherTheme {
        SettingsScreen(onBackPressed = {}, context = LocalContext.current, textIconColor = Color.Black)
    }
}